package entidades

data class Usuario (
    val nickname:String,
    val password:String


)