package main
import entidades.Usuario
import repositorios.UsuarioRepositorio


fun main() {

    val usuarios=UsuarioRepositorio

    do {
        println("Ingrese nickname")
        var nickname: String = readLine().toString()
        println("Ingrese password")
        var password: String = readLine().toString()
        val user = Usuario(nickname, password)

    if (usuarios.validacion(nickname, password)) {
        usuarios.iniciar(nickname, password);
        println("Iniciaste sesion")
    } else {
        println("Usuario y/o contraseña inválidos")
        println("Ingrese nickname")
         nickname= readLine().toString()
        println("Ingrese password")
         password= readLine().toString()
    }
 } while(usuarios.validacion(nickname, password))

 println("Bienvenido a Orange")
    var opcion=0

    do{
     println("Elige una opción \n 1- para comprar Bitcoins" +
             "\n 2 para ver el historial de sus compras" +
             "\n 3 para salir")
        opcion= readLine()?.toInt()!!


     when (opcion){
         1-> println("Elige el exchange \n 1 para criptomas \n 2 para criptodia \n 3 para Carrecripto")
            val exchange:Int= readLine()?.toInt()!!;
     }
 }while (opcion!=3)

}




